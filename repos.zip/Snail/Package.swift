import PackageDescription

let package = Package(
    name: "Snail",
    exclude: ["Carthage", " Snail.xcodeproj", "SnailTests", "circle.yml", "codecov.yml"]
)
